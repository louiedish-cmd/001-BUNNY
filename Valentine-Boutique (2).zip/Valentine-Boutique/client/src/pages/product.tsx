import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";

// Import the generated image
import bunnyKeychainImg from "@assets/Móc_Treo_Trang_Trí_Costume_Bear🧸_&_Circus_Troup🎪Một_chút_náo_1771470714371.jpg";

// --- Types ---
interface Review {
  timestamp: string;
  name: string;
  rating: number;
  review: string;
}

// --- Product Component ---
export default function ProductPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [reviews, setReviews] = useState<Review[]>([]);

  // Load reviews from localStorage on mount
  useEffect(() => {
    const savedReviews = localStorage.getItem("product_reviews");
    if (savedReviews) {
      try {
        setReviews(JSON.parse(savedReviews));
      } catch (e) {
        console.error("Failed to parse saved reviews", e);
      }
    }
  }, []);

  // Save reviews to localStorage whenever they change
  useEffect(() => {
    if (reviews.length > 0) {
      localStorage.setItem("product_reviews", JSON.stringify(reviews));
    }
  }, [reviews]);

  // Form State
  const [name, setName] = useState("");
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Google Apps Script URL (Placeholder - user needs to provide real one)
  const GOOGLE_SCRIPT_URL = "YOUR_GOOGLE_SCRIPT_URL_HERE"; 

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      toast({
        title: "Rating required",
        description: "Please select a heart rating before submitting.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    const newReview = {
      timestamp: new Date().toISOString(),
      name,
      rating,
      review: reviewText,
    };

    try {
      // Optimistic update
      setReviews([newReview, ...reviews]);
      
      // Attempt to send to Google Sheets if URL is valid
      if (GOOGLE_SCRIPT_URL && GOOGLE_SCRIPT_URL !== "YOUR_GOOGLE_SCRIPT_URL_HERE") {
         await fetch(GOOGLE_SCRIPT_URL, {
          method: "POST",
          mode: "no-cors", // Google Forms/Scripts often require no-cors for simple posts
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newReview),
        });
      }
      
      toast({
        title: "Review Submitted",
        description: "Thank you for sharing your story.",
      });

      // Reset Form
      setName("");
      setRating(0);
      setReviewText("");
    } catch (error) {
      console.error("Error submitting review:", error);
      toast({
        title: "Submission Error",
        description: "Could not save to external database, but showing locally.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background selection:bg-primary/20 bg-grain">
      <div className="max-w-6xl mx-auto px-6 py-12 md:py-24 relative z-10">
        
        {/* Top Section: Product */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20 mb-24">
          
          {/* Image Column */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative aspect-square md:aspect-[4/5] overflow-hidden rounded-3xl bg-white shadow-xl shadow-primary/5"
          >
             <img 
               src={bunnyKeychainImg}
               alt="Bunny Keychain"
               className="object-cover w-full h-full hover:scale-105 transition-transform duration-700 ease-out"
             />
             <div className="absolute top-6 left-6 bg-white/90 backdrop-blur px-4 py-1.5 rounded-full text-[10px] font-bold tracking-widest text-primary uppercase shadow-sm">
               Limited Drop
             </div>
          </motion.div>

          {/* Details Column */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="flex flex-col justify-center"
          >
            <span className="text-primary font-bold tracking-widest text-[10px] uppercase mb-4 opacity-60">The Archive 001</span>
            <h1 className="text-5xl md:text-7xl text-foreground mb-8 leading-[0.9] font-black tracking-tighter">
              BUNNY <br/> <span className="italic text-primary font-serif">KEYCHAIN</span>
            </h1>
            
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed font-normal max-w-md">
              <p>
                There are people who make large decisions in life.
                We stood for 30 minutes and chose pocket animals.
              </p>
              <p>
                You picked a bunny. I picked a bear. It felt like a summit meeting. Important. Diplomatic. History books will ignore it, which is a shame.
              </p>
              <p>
                Now they will hang from separate chains in separate cities, doing their quiet little jobs. Guarding bags. Listening to conversations. Witnessing ordinary days.
              </p>
              <p>
                I like that we chose them together. Same set. Different holders. That feels familiar.
              </p>
              <p>
                If anyone asks why a grown man carries a small bear, I will say it was destiny. And also you.
              </p>
              <p className="font-bold text-primary pt-4 text-xl tracking-tight">
                Two years. Still voluntarily matching.
              </p>
            </div>
          </motion.div>
        </div>

        <Separator className="my-20 bg-primary/10" />

        {/* Reviews Section */}
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl mb-4">Customer Stories</h2>
            <p className="text-muted-foreground">Share your moment with us.</p>
          </motion.div>

          {/* Review Form */}
          <Card className="border-none shadow-lg bg-white/50 backdrop-blur-sm mb-16">
            <CardContent className="p-8 md:p-10">
              <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Rating Input */}
                <div className="flex justify-center mb-8">
                  <div className="flex gap-2" onMouseLeave={() => setHoverRating(0)}>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        className="focus:outline-none transition-transform hover:scale-110 active:scale-95"
                        onMouseEnter={() => setHoverRating(star)}
                        onClick={() => setRating(star)}
                      >
                        <Heart 
                          className={`w-8 h-8 transition-colors duration-300 ${
                            (hoverRating || rating) >= star 
                              ? "fill-primary text-primary" 
                              : "text-muted-foreground/30"
                          }`} 
                          strokeWidth={1.5}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Your Name</label>
                    <Input 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Aho"
                      className="bg-white border-primary/10 focus:border-primary/30 h-12 transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Your Story</label>
                    <Textarea 
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      placeholder="Tell us about your experience..."
                      className="bg-white border-primary/10 focus:border-primary/30 min-h-[120px] resize-none transition-colors"
                      required
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-primary hover:bg-primary/90 text-white h-12 rounded-lg text-sm font-medium tracking-wide transition-all duration-300 shadow-md hover:shadow-lg hover:-translate-y-0.5"
                  >
                    {isSubmitting ? "Submitting..." : "Submit Review"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Reviews List */}
          <div className="space-y-6">
            <AnimatePresence mode="popLayout">
              {reviews.map((review, index) => (
                <motion.div
                  key={`${review.name}-${index}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  layout
                >
                  <Card className="border-none shadow-sm bg-white hover:shadow-md transition-shadow duration-300">
                    <CardContent className="p-6 md:p-8 flex flex-col gap-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-serif text-lg text-foreground">{review.name}</h3>
                          <span className="text-xs text-muted-foreground">
                            {new Date(review.timestamp).toLocaleDateString(undefined, {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </span>
                        </div>
                        <div className="flex gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Heart 
                              key={i} 
                              className={`w-4 h-4 ${i < review.rating ? "fill-primary text-primary" : "text-muted-foreground/20"}`} 
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-muted-foreground leading-relaxed font-light">
                        {review.review}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}